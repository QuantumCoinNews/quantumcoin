// cmd/wallet/main_fyne.go
//go:build !wails

package main

import (
	"bufio"
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/json"
	"fmt"
	"image/color"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/scrypt"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"
)

/* ================== UI renkleri ================== */
var (
	colSuccess = color.NRGBA{R: 46, G: 204, B: 113, A: 255} // yeşil
	colInfo    = color.NRGBA{R: 52, G: 152, B: 219, A: 255} // mavi/cyan
	colError   = color.NRGBA{R: 231, G: 76, B: 60, A: 255}  // kırmızı
)

/* ================== Global ================== */
const appVersion = "wallet-gui v1.3"

var (
	apiPort               string
	walletAutoRefreshStop chan struct{}
	lastBalance           float64 // last shown total (confirmed+pending)

	// Miner log & state
	minerLogPath                     = ""
	minerTailStop      chan struct{} = nil
	minerTailMu        sync.Mutex
	minerRunningState  = false
	walletRefreshHook  func()
	onMinerStateUpdate func(bool)
)

var (
	langSelect *widget.Select
)

// ---- Miner komut sabitleri ----
const minerSubcommand = "mine"  // referans
const minerNeedsAddrFlag = true // referans

/* ============ Helpers ============ */

func ui(f func()) { fyne.Do(f) }

func exeDir() string {
	self, _ := os.Executable()
	return filepath.Dir(self)
}

/* ============ Theme ============ */

func applyTheme(name string) {
	switch strings.ToLower(strings.TrimSpace(name)) {
	case "karanlık", "dark":
		fyne.CurrentApp().Settings().SetTheme(theme.DarkTheme())
	case "aydınlık", "light":
		fyne.CurrentApp().Settings().SetTheme(theme.LightTheme())
	default:
		fyne.CurrentApp().Settings().SetTheme(theme.DefaultTheme())
	}
}

/* ============ mined_balance.json path ============ */

func minedJSONPath() string {
	candidates := []string{}
	if v := strings.TrimSpace(os.Getenv("QC_MINED_PATH")); v != "" {
		candidates = append(candidates, v)
	}
	if v := strings.TrimSpace(os.Getenv("QC_NODE_DIR")); v != "" {
		candidates = append(candidates,
			filepath.Join(v, "mined_balance.json"),
			filepath.Join(v, "miner", "mined_balance.json"),
			filepath.Join(v, "data", "mined_balance.json"),
		)
	}
	if runtime.GOOS == "windows" {
		candidates = append(candidates,
			`C:\QuantumMiner\mined_balance.json`,
			`C:\QuantumMiner\miner\mined_balance.json`,
			`C:\QuantumMiner\data\mined_balance.json`,
		)
	}
	d := exeDir()
	candidates = append(candidates,
		filepath.Join(d, "mined_balance.json"),
		filepath.Join(d, "miner", "mined_balance.json"),
	)
	if wd, err := os.Getwd(); err == nil {
		candidates = append(candidates,
			filepath.Join(wd, "mined_balance.json"),
			filepath.Join(wd, "miner", "mined_balance.json"),
		)
	}
	altNames := []string{"mined.json", "mining_balance.json", "rewards.json", "miner_balance.json"}
	baseDirs := []string{d}
	if v := strings.TrimSpace(os.Getenv("QC_NODE_DIR")); v != "" {
		baseDirs = append(baseDirs, v)
	}
	if runtime.GOOS == "windows" {
		baseDirs = append(baseDirs, `C:\QuantumMiner`, `C:\QuantumMiner\data`, `C:\QuantumMiner\miner`)
	}
	for _, bd := range baseDirs {
		for _, name := range altNames {
			candidates = append(candidates, filepath.Join(bd, name))
		}
	}
	for _, p := range candidates {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return filepath.Join(exeDir(), "mined_balance.json")
}

/* ============ Miner status helpers ============ */

func isProcessAlive(pid int) bool {
	if pid <= 0 {
		return false
	}
	if runtime.GOOS == "windows" {
		out, _ := exec.Command("tasklist", "/FI", fmt.Sprintf("PID eq %d", pid)).CombinedOutput()
		return strings.Contains(string(out), fmt.Sprintf("%d", pid))
	}
	return exec.Command("kill", "-0", fmt.Sprint(pid)).Run() == nil
}

/* ===== Miner PID (only for our launched process) ===== */

func minerPIDPath() string { return filepath.Join(exeDir(), "miner_pid.txt") }

func writeMinerPID(pid int) { _ = os.WriteFile(minerPIDPath(), []byte(strconv.Itoa(pid)), 0644) }
func readMinerPID() (int, error) {
	b, e := os.ReadFile(minerPIDPath())
	if e != nil {
		return 0, e
	}
	return strconv.Atoi(strings.TrimSpace(string(b)))
}
func clearMinerPID() { _ = os.Remove(minerPIDPath()) }

func minerActiveViaAPI() bool {
	if apiPort == "" {
		apiPort = detectAPIPort()
	}
	if !portHasAPI(apiPort) {
		return false
	}
	client := &http.Client{Timeout: 700 * time.Millisecond}
	for _, p := range []string{"/api/miner/status", "/api/miner"} {
		resp, err := client.Get(apiBase() + p)
		if err != nil {
			continue
		}
		b, _ := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		var m map[string]interface{}
		if json.Unmarshal(b, &m) == nil {
			for _, k := range []string{"active", "running", "mining", "is_active"} {
				switch v := m[k].(type) {
				case bool:
					if v {
						return true
					}
				case string:
					if strings.EqualFold(v, "true") || strings.EqualFold(v, "running") || strings.EqualFold(v, "active") {
						return true
					}
				}
			}
		}
	}
	return false
}

func minerActiveHeuristic() bool {
	if pid, err := readMinerPID(); err == nil && isProcessAlive(pid) {
		return true
	}
	return minerActiveViaAPI()
}

/* ============ Node dir & addresses ============ */

func nodeDir() string {
	d := exeDir()
	if _, err := os.Stat(filepath.Join(d, "quantumcoin.exe")); err == nil {
		return d
	}
	if v := strings.TrimSpace(os.Getenv("QC_NODE_DIR")); v != "" {
		if _, err := os.Stat(filepath.Join(v, "quantumcoin.exe")); err == nil {
			return v
		}
	}
	if runtime.GOOS == "windows" {
		if _, err := os.Stat(`C:\QuantumMiner\quantumcoin.exe`); err == nil {
			return `C:\QuantumMiner`
		}
	}
	if wd, err := os.Getwd(); err == nil {
		if _, err := os.Stat(filepath.Join(wd, "quantumcoin.exe")); err == nil {
			return wd
		}
	}
	return d
}

func walletAddressPath() string { return filepath.Join(nodeDir(), "wallet_address.txt") }
func minerAddressPath() string  { return filepath.Join(nodeDir(), "miner_address.txt") }
func walletPrivPath() string    { return filepath.Join(nodeDir(), "wallet_priv.hex") }

func saveText(path, s string) error { return os.WriteFile(path, []byte(strings.TrimSpace(s)), 0644) }
func loadText(path string) string {
	b, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}

func detectExistingAddress() string {
	if v := loadText(walletAddressPath()); v != "" {
		return v
	}
	if v := loadText(minerAddressPath()); v != "" {
		return v
	}
	// %APPDATA%\QuantumCoin\wallet.json (GUI/diğer)
	if runtime.GOOS == "windows" {
		if app := strings.TrimSpace(os.Getenv("APPDATA")); app != "" {
			p := filepath.Join(app, "QuantumCoin", "wallet.json")
			if b, err := os.ReadFile(p); err == nil {
				var w struct {
					Address string `json:"address"`
				}
				if json.Unmarshal(b, &w) == nil && strings.TrimSpace(w.Address) != "" {
					return strings.TrimSpace(w.Address)
				}
			}
		}
	}
	return ""
}

func genAddressViaNode() (string, error) {
	exe := filepath.Join(nodeDir(), "quantumcoin.exe")
	if _, err := os.Stat(exe); err != nil {
		return "", fmt.Errorf("quantumcoin.exe not found: %w", err)
	}
	cmd := exec.Command(exe, "newaddr")
	cmd.Dir = nodeDir()
	out, err := cmd.CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("newaddr error: %w (out=%s)", err, string(out))
	}
	s := string(out)
	if i := strings.Index(s, "New Wallet Address:"); i >= 0 {
		part := strings.TrimSpace(s[i+len("New Wallet Address:"):])
		if j := strings.IndexByte(part, '\n'); j >= 0 {
			part = part[:j]
		}
		if part != "" {
			return part, nil
		}
	}
	re := regexp.MustCompile(`\b[13][a-km-zA-HJ-NP-Z1-9]{25,49}\b`)
	if m := re.FindString(s); m != "" {
		return m, nil
	}
	return "", fmt.Errorf("address not found in newaddr output")
}

// Adres + private key (hex) birlikte üret ve döndür
func genAddressPrivViaNode() (addr, privHex string, err error) {
	exe := filepath.Join(nodeDir(), "quantumcoin.exe")
	if _, e := os.Stat(exe); e != nil {
		err = fmt.Errorf("quantumcoin.exe not found: %w", e)
		return
	}
	cmd := exec.Command(exe, "newaddr-priv")
	cmd.Dir = nodeDir()
	out, e := cmd.CombinedOutput()
	if e != nil {
		err = fmt.Errorf("newaddr-priv error: %w (out=%s)", e, string(out))
		return
	}
	s := string(out)
	// Address
	if i := strings.Index(s, "New Wallet Address:"); i >= 0 {
		part := strings.TrimSpace(s[i+len("New Wallet Address:"):])
		if j := strings.IndexByte(part, '\n'); j >= 0 {
			part = part[:j]
		}
		addr = strings.TrimSpace(part)
	}
	// Private key hex
	if i := strings.Index(s, "PrivateKey (hex):"); i >= 0 {
		part := strings.TrimSpace(s[i+len("PrivateKey (hex):"):])
		if j := strings.IndexByte(part, '\n'); j >= 0 {
			part = part[:j]
		}
		privHex = strings.TrimSpace(part)
	}
	if addr == "" {
		// address fallback
		re := regexp.MustCompile(`\b[13][a-km-zA-HJ-NP-Z1-9]{25,49}\b`)
		addr = re.FindString(s)
	}
	if addr == "" || privHex == "" {
		err = fmt.Errorf("could not parse address/private key")
		return
	}
	return
}

/* ================== API utils ================== */

func ping(u string, t time.Duration) error {
	client := &http.Client{Timeout: t}
	resp, err := client.Get(u)
	if err != nil {
		return err
	}
	io.Copy(io.Discard, resp.Body)
	_ = resp.Body.Close()
	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusNoContent {
		return fmt.Errorf("bad status: %s", resp.Status)
	}
	return nil
}

func portHasAPI(p string) bool {
	candidates := []string{
		"http://127.0.0.1:" + p + "/health",
		"http://127.0.0.1:" + p + "/api/health",
		"http://127.0.0.1:" + p + "/api/status",
		"http://127.0.0.1:" + p + "/api/version",
	}
	for _, u := range candidates {
		if ping(u, 400*time.Millisecond) == nil {
			return true
		}
	}
	return false
}

func detectAPIPort() string {
	for _, k := range []string{"QC_HTTP_PORT", "HTTP_PORT"} {
		if p := strings.TrimSpace(os.Getenv(k)); p != "" && portHasAPI(p) {
			return p
		}
	}
	for _, p := range []string{"8082", "8081", "3001", "8080", "9090", "9091", "3000"} {
		if portHasAPI(p) {
			return p
		}
	}
	return "8081"
}

func apiBase() string {
	if apiPort == "" {
		apiPort = detectAPIPort()
	}
	return "http://127.0.0.1:" + apiPort
}

func apiPost(path string, body interface{}, to time.Duration) error {
	b := []byte("{}")
	if body != nil {
		var err error
		b, err = json.Marshal(body)
		if err != nil {
			return err
		}
	}
	client := &http.Client{Timeout: to}
	resp, err := client.Post(apiBase()+path, "application/json", bytes.NewReader(b))
	if err != nil {
		return err
	}
	io.Copy(io.Discard, resp.Body)
	_ = resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("http %d", resp.StatusCode)
	}
	return nil
}

/* ================== i18n ================== */

type dict map[string]string

var curLang = "tr"

var i18n = map[string]dict{
	"tr": {
		"title":           "QuantumCoin Cüzdan & Madenci",
		"tab_wallet":      "Cüzdan",
		"tab_mine":        "Madenci",
		"tab_web":         "Web Cüzdan",
		"open_web_wallet": "Web Cüzdanı Aç",
		"web_wallet_url":  "Web Cüzdan URL: %s",

		"balance":         "Bakiye",
		"balance_na":      "Bakiye: (okunamadı)",
		"balance_api":     "Bakiye: (API kapalı)",
		"refresh":         "Yenile",
		"my_address":      "Cüzdan Adresim",
		"from":            "Gönderen (From)",
		"to":              "Alıcı (Adres)",
		"amount":          "Miktar (QC)",
		"fee":             "Ücret (ops.)",
		"send":            "Gönder",
		"copy":            "Kopyala",
		"paste":           "Yapıştır",
		"save":            "Kaydet",
		"start_api_bg":    "API’yi Arka Planda Başlat",
		"miner_start":     "Madenciliği Başlat",
		"miner_stop":      "Madenciliği Durdur",
		"reward_addr":     "Ödül Adresi",
		"addr_empty":      "Adres boş",
		"api_timeout":     "API’ye erişilemedi.",
		"tx_sent":         "İşlem gönderildi!",
		"ok":              "Tamam",
		"receive_copy":    "Al (Adresimi Kopyala)",
		"auto_refresh_on": "Otomatik Yenileme (3 sn)",
		"generate_wallet": "Yeni Cüzdan Oluştur",

		"miner_status": "Durum",
		"running":      "Çalışıyor",
		"stopped":      "Durdu",
		"logs":         "Kayıtlar",
	},
	"en": {
		"title":           "QuantumCoin Wallet & Miner",
		"tab_wallet":      "Wallet",
		"tab_mine":        "Miner",
		"tab_web":         "Web Wallet",
		"open_web_wallet": "Open Web Wallet",
		"web_wallet_url":  "Web Wallet URL: %s",

		"balance":         "Balance",
		"balance_na":      "Balance: (unavailable)",
		"balance_api":     "Balance: (API down)",
		"refresh":         "Refresh",
		"my_address":      "My Wallet Address",
		"from":            "From (Sender)",
		"to":              "To (Address)",
		"amount":          "Amount (QC)",
		"fee":             "Fee (opt.)",
		"send":            "Send",
		"copy":            "Copy",
		"paste":           "Paste",
		"save":            "Save",
		"start_api_bg":    "Start API (Background)",
		"miner_start":     "Start Mining",
		"miner_stop":      "Stop Mining",
		"reward_addr":     "Reward Address",
		"addr_empty":      "Address is empty",
		"api_timeout":     "Could not reach API.",
		"tx_sent":         "Transaction sent!",
		"ok":              "OK",
		"receive_copy":    "Receive (Copy My Address)",
		"auto_refresh_on": "Auto Refresh (3s)",
		"generate_wallet": "Generate New Wallet",

		"miner_status": "Status",
		"running":      "Running",
		"stopped":      "Stopped",
		"logs":         "Logs",
	},
	"es": {
		"title":           "QuantumCoin Billetera & Minero",
		"tab_wallet":      "Billetera",
		"tab_mine":        "Minero",
		"tab_web":         "Billetera Web",
		"open_web_wallet": "Abrir Billetera Web",
		"web_wallet_url":  "URL de Billetera Web: %s",

		"balance":         "Saldo",
		"balance_na":      "Saldo: (no disponible)",
		"balance_api":     "Saldo: (API caída)",
		"refresh":         "Actualizar",
		"my_address":      "Mi Dirección de Billetera",
		"from":            "Remitente (From)",
		"to":              "Destinatario (Dirección)",
		"amount":          "Monto (QC)",
		"fee":             "Tarifa (op.)",
		"send":            "Enviar",
		"copy":            "Copiar",
		"paste":           "Pegar",
		"save":            "Guardar",
		"start_api_bg":    "Iniciar API (Segundo plano)",
		"miner_start":     "Iniciar Minería",
		"miner_stop":      "Detener Minería",
		"reward_addr":     "Dirección de Recompensa",
		"addr_empty":      "La dirección está vacía",
		"api_timeout":     "No se pudo alcanzar la API.",
		"tx_sent":         "¡Transacción enviada!",
		"ok":              "OK",
		"receive_copy":    "Recibir (Copiar mi dirección)",
		"auto_refresh_on": "Actualización Automática (3s)",
		"generate_wallet": "Generar Nueva Billetera",

		"miner_status": "Estado",
		"running":      "En ejecución",
		"stopped":      "Detenido",
		"logs":         "Registros",
	},
	"zh": {
		"title":           "QuantumCoin 钱包与矿工",
		"tab_wallet":      "钱包",
		"tab_mine":        "矿工",
		"tab_web":         "网页版钱包",
		"open_web_wallet": "打开网页版钱包",
		"web_wallet_url":  "网页版钱包地址：%s",

		"balance":         "余额",
		"balance_na":      "余额：（不可用）",
		"balance_api":     "余额：（API 离线）",
		"refresh":         "刷新",
		"my_address":      "我的钱包地址",
		"from":            "发送方（From）",
		"to":              "接收方（地址）",
		"amount":          "数量（QC）",
		"fee":             "手续费（可选）",
		"send":            "发送",
		"copy":            "复制",
		"paste":           "粘贴",
		"save":            "保存",
		"start_api_bg":    "后台启动 API",
		"miner_start":     "开始挖矿",
		"miner_stop":      "停止挖矿",
		"reward_addr":     "奖励地址",
		"addr_empty":      "地址为空",
		"api_timeout":     "无法连接到 API。",
		"tx_sent":         "交易已发送！",
		"ok":              "确定",
		"receive_copy":    "接收（复制我的地址）",
		"auto_refresh_on": "自动刷新（3秒）",
		"generate_wallet": "生成新钱包",

		"miner_status": "状态",
		"running":      "运行中",
		"stopped":      "已停止",
		"logs":         "日志",
	},
}

func T(k string) string {
	if d, ok := i18n[curLang]; ok {
		if v, ok2 := d[k]; ok2 {
			return v
		}
	}
	return k
}

/* ========== mined_balance.json tolerant reader & pending ========== */

type minedBalance struct {
	Addr      string  `json:"addr"`
	Balance   float64 `json:"balance"`
	UpdatedAt int64   `json:"updated_at"`
}

func readLocalMined() (minedBalance, error) {
	var m minedBalance
	p := minedJSONPath()
	b, err := os.ReadFile(p)
	if err != nil {
		return m, err
	}

	if err := json.Unmarshal(b, &m); err == nil && (m.Addr != "" || m.Balance != 0) {
		return m, nil
	}

	var m2 map[string]interface{}
	if err := json.Unmarshal(b, &m2); err != nil {
		return m, err
	}
	if s, ok := m2["addr"].(string); ok && s != "" {
		m.Addr = strings.TrimSpace(s)
	}
	if s, ok := m2["address"].(string); ok && s != "" && m.Addr == "" {
		m.Addr = strings.TrimSpace(s)
	}

	candidates := []string{
		"balance", "confirmed_balance", "confirmed", "spendable",
		"available", "total", "mined_total", "mined", "reward", "rewards", "amount", "pending",
	}
	parseNum := func(v interface{}) (float64, bool) {
		switch t := v.(type) {
		case float64:
			return t, true
		case json.Number:
			if f, err := t.Float64(); err == nil {
				return f, true
			}
		case string:
			if f, err := strconv.ParseFloat(strings.TrimSpace(t), 64); err == nil {
				return f, true
			}
		}
		return 0, false
	}
	for _, k := range candidates {
		if v, ok := m2[k]; ok {
			if f, ok := parseNum(v); ok {
				m.Balance = f
				break
			}
		}
	}
	if v, ok := m2["updated_at"].(float64); ok {
		m.UpdatedAt = int64(v)
	} else if v, ok := m2["updated"].(float64); ok {
		m.UpdatedAt = int64(v)
	}

	if m.Balance == 0 {
		re := regexp.MustCompile(`[-+]?\d+(\.\d+)?`)
		if g := re.FindString(string(b)); g != "" {
			if f, err := strconv.ParseFloat(g, 64); err == nil {
				m.Balance = f
			}
		}
	}
	if m.Balance == 0 && m.Addr == "" && m.UpdatedAt == 0 {
		return m, fmt.Errorf("unsupported mined_balance.json")
	}
	return m, nil
}

func getPendingForAddr(addr string) float64 {
	if m, err := readLocalMined(); err == nil {
		if m.Addr == "" || strings.EqualFold(strings.TrimSpace(m.Addr), strings.TrimSpace(addr)) {
			if m.Balance < 0 {
				return 0
			}
			return m.Balance
		}
	}
	return 0
}

/* ===== Balance cache ===== */

func balanceCachePath() string { return filepath.Join(nodeDir(), "wallet_balance.cache.json") }

func saveBalanceCache(addr string, bal float64) {
	m := map[string]interface{}{"address": addr, "balance": bal, "updated_at": time.Now().Unix()}
	b, _ := json.MarshalIndent(m, "", "  ")
	_ = os.WriteFile(balanceCachePath(), b, 0644)
}

func loadBalanceCache(addr string) (float64, bool) {
	b, err := os.ReadFile(balanceCachePath())
	if err != nil {
		return 0, false
	}
	var m map[string]interface{}
	if json.Unmarshal(b, &m) != nil {
		return 0, false
	}
	a, _ := m["address"].(string)
	if strings.TrimSpace(a) == "" || !strings.EqualFold(strings.TrimSpace(a), strings.TrimSpace(addr)) {
		return 0, false
	}
	switch v := m["balance"].(type) {
	case float64:
		return v, true
	case json.Number:
		f, _ := v.Float64()
		return f, true
	case string:
		if f, err := strconv.ParseFloat(strings.TrimSpace(v), 64); err == nil {
			return f, true
		}
	}
	return 0, false
}

/* ===== API helpers for numbers ===== */

func numericFromAny(v interface{}) (float64, bool) {
	switch t := v.(type) {
	case float64:
		return t, true
	case float32:
		return float64(t), true
	case int:
		return float64(t), true
	case int64:
		return float64(t), true
	case json.Number:
		if f, err := t.Float64(); err == nil {
			return f, true
		}
	case string:
		s := strings.TrimSpace(t)
		if f, err := strconv.ParseFloat(s, 64); err == nil {
			return f, true
		}
		re := regexp.MustCompile(`[-+]?\d+(\.\d+)?`)
		if g := re.FindString(s); g != "" {
			if f, err := strconv.ParseFloat(g, 64); err == nil {
				return f, true
			}
		}
	}
	return 0, false
}

func getStringAnyKey(m map[string]interface{}, keys ...string) string {
	for _, k := range keys {
		if v, ok := m[k]; ok {
			if s, ok2 := v.(string); ok2 && strings.TrimSpace(s) != "" {
				return strings.TrimSpace(s)
			}
		}
	}
	return ""
}

func getAnyKey(m map[string]interface{}, keys ...string) interface{} {
	for _, k := range keys {
		if v, ok := m[k]; ok {
			return v
		}
	}
	return nil
}

/* ========== API balance fetcher (confirmed + pending) - tolerant ========== */

func findBalancesInMapTolerant(m map[string]interface{}) (confirmed float64, pending float64) {
	if f, ok := numericFromAny(getAnyKey(m, "confirmed_balance", "confirmed", "spendable", "available")); ok {
		confirmed = f
	}
	if confirmed == 0 {
		if f, ok := numericFromAny(getAnyKey(m, "balance", "Balance", "total", "Total")); ok {
			confirmed = f
		}
	}
	if f, ok := numericFromAny(getAnyKey(m, "pending", "unconfirmed", "immature", "pending_balance")); ok {
		pending = f
	}
	if bsub, ok := m["balance"].(map[string]interface{}); ok {
		if f, ok := numericFromAny(bsub["confirmed"]); ok {
			confirmed = f
		}
		if f, ok := numericFromAny(bsub["pending"]); ok {
			pending = f
		}
		if confirmed == 0 {
			if tot, ok := numericFromAny(bsub["total"]); ok {
				if pending > 0 {
					confirmed = tot - pending
				} else {
					confirmed = tot
				}
			}
		}
	}
	return
}

func fetchAPIBalances(addr string) (float64, float64, bool) {
	addr = strings.TrimSpace(addr)
	if addr == "" {
		return 0, 0, false
	}
	if apiPort == "" {
		apiPort = detectAPIPort()
	}

	client := &http.Client{Timeout: 2500 * time.Millisecond}
	paths := []string{
		"/api/address/balance?addr=" + url.QueryEscape(addr),
		"/api/wallet/balance/" + url.PathEscape(addr),
		"/api/balance?addr=" + url.QueryEscape(addr),
		"/api/address/" + url.PathEscape(addr) + "/balance",
		"/api/address/" + url.PathEscape(addr),
		"/address/" + url.PathEscape(addr) + "/balance",
		"/wallet/balance/" + url.PathEscape(addr),
		"/balance/" + url.PathEscape(addr),
	}

	for _, p := range paths {
		u := apiBase() + p
		resp, err := client.Get(u)
		if err != nil {
			continue
		}
		ct := strings.ToLower(resp.Header.Get("Content-Type"))
		body, _ := io.ReadAll(resp.Body)
		_ = resp.Body.Close()

		trim := strings.TrimSpace(string(body))
		if len(trim) == 0 || strings.HasPrefix(trim, "<!doctype") || strings.HasPrefix(trim, "<html") || strings.Contains(ct, "text/html") {
			continue
		}

		var anyval interface{}
		if json.Unmarshal(body, &anyval) != nil {
			re := regexp.MustCompile(`[-+]?\d+(\.\d+)?`)
			if g := re.FindString(trim); g != "" {
				if f, err := strconv.ParseFloat(g, 64); err == nil {
					return f, 0, true
				}
			}
			continue
		}

		switch v := anyval.(type) {
		case map[string]interface{}:
			gotAddr := getStringAnyKey(v, "address", "addr", "account", "wallet")
			if gotAddr != "" && !strings.EqualFold(strings.TrimSpace(gotAddr), addr) {
				continue
			}
			c, p := findBalancesInMapTolerant(v)
			if c > 0 || p > 0 {
				return c, p, true
			}
		case []interface{}:
			for _, it := range v {
				if m, ok := it.(map[string]interface{}); ok {
					gotAddr := getStringAnyKey(m, "address", "addr", "account", "wallet")
					if gotAddr != "" && !strings.EqualFold(strings.TrimSpace(gotAddr), addr) {
						continue
					}
					c, p := findBalancesInMapTolerant(m)
					if c > 0 || p > 0 {
						return c, p, true
					}
				}
			}
		default:
			if f, ok := numericFromAny(v); ok {
				return f, 0, true
			}
		}
	}
	return 0, 0, false
}

/* ================== Tek adresli bonus_store helper ================== */

func ensureBonusStore(addr string) {
	p := filepath.Join(nodeDir(), "bonus_store.json")
	if _, err := os.Stat(p); err == nil {
		return // varsa dokunma
	}
	m := map[string]interface{}{
		"community_address": addr,
		"dev_fund_address":  addr,
		"premine_address":   addr,
		"reward_percentages": map[string]int{
			"miner":     95,
			"community": 5,
			"dev":       0,
			"premine":   0,
		},
	}
	b, _ := json.MarshalIndent(m, "", "  ")
	_ = os.WriteFile(p, b, 0644)
}

/* ================== UI: Wallet ================== */

func detectPrivHex() string {
	// 1) yerel dosya
	if v := loadText(walletPrivPath()); v != "" {
		return v
	}
	// 2) %APPDATA%\QuantumCoin\wallet.json
	if runtime.GOOS == "windows" {
		if app := strings.TrimSpace(os.Getenv("APPDATA")); app != "" {
			p := filepath.Join(app, "QuantumCoin", "wallet.json")
			if b, err := os.ReadFile(p); err == nil {
				var w struct {
					PrivHex string `json:"priv_hex"`
				}
				if json.Unmarshal(b, &w) == nil && strings.TrimSpace(w.PrivHex) != "" {
					return strings.TrimSpace(w.PrivHex)
				}
			}
		}
	}
	return ""
}

func makeWalletTab(w fyne.Window, myAddrEntry, fromEntry *widget.Entry) fyne.CanvasObject {
	toEntry := widget.NewEntry()
	toEntry.SetPlaceHolder(T("to"))
	amtEntry := widget.NewEntry()
	amtEntry.SetPlaceHolder(T("amount"))
	feeEntry := widget.NewEntry()
	feeEntry.SetPlaceHolder(T("fee"))

	balanceText := canvas.NewText(T("balance_na"), color.NRGBA{R: 140, G: 140, B: 140, A: 255})
	balanceText.TextSize = 22
	balanceText.TextStyle.Bold = true

	copyMyBtn := widget.NewButton(T("copy"), func() { w.Clipboard().SetContent(myAddrEntry.Text) })
	receiveBtn := widget.NewButton(T("receive_copy"), func() {
		w.Clipboard().SetContent(myAddrEntry.Text)
		dialog.ShowInformation(T("ok"), myAddrEntry.Text, w)
	})
	pasteToBtn := widget.NewButton(T("paste"), func() { toEntry.SetText(w.Clipboard().Content()) })

	genBtn := widget.NewButton(T("generate_wallet"), func() {
		addr, priv, err := genAddressPrivViaNode()
		if err != nil {
			dialog.ShowError(err, w)
			return
		}
		_ = saveText(walletAddressPath(), addr)
		_ = saveText(minerAddressPath(), addr)
		_ = saveText(walletPrivPath(), priv)
		myAddrEntry.SetText(addr)
		fromEntry.SetText(addr)
		dialog.ShowInformation(T("ok"), addr, w)
	})

	// Bakiye yenileyici
	doRefresh := func() {
		addr := strings.TrimSpace(myAddrEntry.Text)
		if addr == "" {
			addr = strings.TrimSpace(fromEntry.Text)
		}
		if addr == "" {
			ui(func() {
				balanceText.Text = T("balance_na")
				balanceText.Color = color.NRGBA{R: 140, G: 140, B: 140, A: 255}
				canvas.Refresh(balanceText)
			})
			return
		}

		pendingLocal := getPendingForAddr(addr)

		if confirmed, pendingAPI, ok := fetchAPIBalances(addr); ok {
			pending := pendingAPI
			if pendingLocal > pending {
				pending = pendingLocal
			}
			total := confirmed + pending
			saveBalanceCache(addr, total)

			ui(func() {
				if total > lastBalance {
					balanceText.Color = colSuccess
				} else if total < lastBalance {
					balanceText.Color = colError
				} else {
					balanceText.Color = colInfo
				}
				if pending > 1e-7 {
					balanceText.Text = fmt.Sprintf(
						"%s: %.8f QC   (confirmed: %.8f • pending: %.8f)",
						T("balance"), total, confirmed, pending,
					)
				} else {
					balanceText.Text = fmt.Sprintf("%s: %.8f QC", T("balance"), total)
				}
				canvas.Refresh(balanceText)
				lastBalance = total
			})
			return
		}

		if pendingLocal > 0 {
			total := pendingLocal
			saveBalanceCache(addr, total)
			ui(func() {
				if total > lastBalance {
					balanceText.Color = colSuccess
				} else if total < lastBalance {
					balanceText.Color = colError
				} else {
					balanceText.Color = colInfo
				}
				balanceText.Text = fmt.Sprintf("%s: ~%.8f QC   (offline • pending)", T("balance"), total)
				canvas.Refresh(balanceText)
				lastBalance = total
			})
			return
		}

		if total, ok := loadBalanceCache(addr); ok {
			ui(func() {
				balanceText.Color = colInfo
				balanceText.Text = fmt.Sprintf("%s: %.8f QC", T("balance"), total)
				canvas.Refresh(balanceText)
				lastBalance = total
			})
			return
		}

		ui(func() {
			balanceText.Text = T("balance_api")
			balanceText.Color = color.NRGBA{R: 200, G: 60, B: 60, A: 255}
			canvas.Refresh(balanceText)
		})
	}

	walletRefreshHook = func() { go doRefresh() }

	refreshBtn := widget.NewButton(T("refresh"), func() {
		_ = startAPIBackground() // gerekirse kaldırır
		go doRefresh()
	})

	startAPIbtn := widget.NewButton(T("start_api_bg"), func() {
		if err := startAPIBackground(); err != nil {
			dialog.ShowError(fmt.Errorf("%s %v", T("api_timeout"), err), w)
			return
		}
		time.AfterFunc(800*time.Millisecond, func() { refreshBtn.Tapped(nil) })
	})

	// Auto refresh (3s)
	if walletAutoRefreshStop != nil {
		close(walletAutoRefreshStop)
	}
	walletAutoRefreshStop = make(chan struct{})
	go func(stop <-chan struct{}) {
		time.Sleep(600 * time.Millisecond)
		doRefresh()
		t := time.NewTicker(3 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-t.C:
				doRefresh()
			case <-stop:
				return
			}
		}
	}(walletAutoRefreshStop)

	form := widget.NewForm(
		widget.NewFormItem(T("my_address"), container.NewBorder(nil, nil, genBtn, copyMyBtn, myAddrEntry)),
		widget.NewFormItem(T("from"), fromEntry),
		widget.NewFormItem(T("to"), container.NewBorder(nil, nil, nil, pasteToBtn, toEntry)),
		widget.NewFormItem(T("amount"), amtEntry),
		widget.NewFormItem(T("fee"), feeEntry),
	)

	// ----- Cüzdan Yedek / Geri Yükle -----
	backupBtn := widget.NewButton("Cüzdanı Yedekle", func() {
		fs := dialog.NewFileSave(func(uc fyne.URIWriteCloser, err error) {
			if err != nil || uc == nil {
				return
			}
			path := uc.URI().Path()
			uc.Close()

			pass := widget.NewEntry()
			pass.Password = true
			dialog.NewCustomConfirm("Yedek Parolası", "Tamam", "İptal",
				container.NewVBox(widget.NewLabel("Yedek parolasını girin:"), pass),
				func(ok bool) {
					if !ok {
						return
					}
					if strings.TrimSpace(pass.Text) == "" {
						dialog.ShowError(fmt.Errorf("Parola boş olamaz"), w)
						return
					}
					if err := createWalletBackup(path, pass.Text); err != nil {
						dialog.ShowError(err, w)
						return
					}
					dialog.ShowInformation("Tamam", "Yedek oluşturuldu.", w)
				}, w).Show()
		}, w)
		fs.SetFileName("qc_wallet_backup.qcbak")
		fs.Show()
	})

	restoreBtn := widget.NewButton("Cüzdanı Geri Yükle", func() {
		fo := dialog.NewFileOpen(func(ur fyne.URIReadCloser, err error) {
			if err != nil || ur == nil {
				return
			}
			path := ur.URI().Path()
			ur.Close()

			pass := widget.NewEntry()
			pass.Password = true
			dialog.NewCustomConfirm("Yedek Parolası", "Tamam", "İptal",
				container.NewVBox(widget.NewLabel("Parolayı girin:"), pass),
				func(ok bool) {
					if !ok {
						return
					}
					if err := restoreWalletBackup(path, pass.Text); err != nil {
						dialog.ShowError(err, w)
						return
					}
					dialog.ShowInformation("Tamam", "Geri yüklendi (uygulamayı yeniden başlatın).", w)
				}, w).Show()
		}, w)
		fo.Show()
	})

	sendBtn := widget.NewButton(T("send"), func() {
		if err := startAPIBackground(); err != nil {
			dialog.ShowError(fmt.Errorf("%s %v", T("api_timeout"), err), w)
			return
		}
		privHex := strings.TrimSpace(detectPrivHex())
		if privHex == "" {
			dialog.ShowError(fmt.Errorf("Özel anahtar bulunamadı. 'Yeni Cüzdan Oluştur' ile anahtar üretin."), w)
			return
		}
		body := map[string]string{
			"from":     strings.TrimSpace(fromEntry.Text),
			"to":       strings.TrimSpace(toEntry.Text),
			"amount":   strings.TrimSpace(amtEntry.Text),
			"fee":      strings.TrimSpace(feeEntry.Text),
			"priv_hex": privHex,
		}
		if body["from"] == "" || body["to"] == "" || body["amount"] == "" {
			dialog.ShowError(fmt.Errorf("from/to/amount gerekli"), w)
			return
		}
		// /api/tx/send dene; olmazsa /api/send fallback
		if err := apiPost("/api/tx/send", body, 8*time.Second); err != nil {
			if err2 := apiPost("/api/send", body, 8*time.Second); err2 != nil {
				dialog.ShowError(fmt.Errorf("Gönderilemedi: %v / %v", err, err2), w)
				return
			}
		}
		dialog.ShowInformation(T("ok"), T("tx_sent"), w)
		toEntry.SetText("")
		amtEntry.SetText("")
		go func() {
			deadline := time.Now().Add(10 * time.Second)
			for time.Now().Before(deadline) {
				time.Sleep(2 * time.Second)
				refreshBtn.Tapped(nil)
			}
		}()
	})

	return container.NewVBox(
		container.NewHBox(balanceText, refreshBtn, startAPIbtn, receiveBtn),
		form,
		container.NewHBox(sendBtn, backupBtn, restoreBtn),
	)
}

/* ================== AES-GCM Yedek/Geri Yükle helpers ================== */

const (
	scryptN = 1 << 15
	scryptR = 8
	scryptP = 1
	keyLen  = 32
)

func deriveKey(pass string, salt []byte) ([]byte, error) {
	return scrypt.Key([]byte(pass), salt, scryptN, scryptR, scryptP, keyLen)
}

func encryptJSONToFile(path string, data interface{}, pass string) error {
	b, err := json.Marshal(data)
	if err != nil {
		return err
	}
	salt := make([]byte, 16)
	if _, err := rand.Read(salt); err != nil {
		return err
	}
	key, err := deriveKey(pass, salt)
	if err != nil {
		return err
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return err
	}
	ct := gcm.Seal(nil, nonce, b, nil)

	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	if _, err := f.Write(salt); err != nil {
		return err
	}
	if _, err := f.Write(nonce); err != nil {
		return err
	}
	if _, err := f.Write(ct); err != nil {
		return err
	}
	return nil
}

func decryptJSONFromFile(path string, pass string, out interface{}) error {
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if len(b) < 16 {
		return fmt.Errorf("bozuk dosya")
	}
	salt := b[:16]
	key, err := deriveKey(pass, salt)
	if err != nil {
		return err
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}
	ns := gcm.NonceSize()
	if len(b) < 16+ns {
		return fmt.Errorf("bozuk dosya (nonce)")
	}
	nonce := b[16 : 16+ns]
	ct := b[16+ns:]
	pt, err := gcm.Open(nil, nonce, ct, nil)
	if err != nil {
		return err
	}
	return json.Unmarshal(pt, out)
}

func createWalletBackup(targetPath, pass string) error {
	dir := nodeDir()
	m := map[string]interface{}{}

	if b, err := os.ReadFile(filepath.Join(dir, "wallet_address.txt")); err == nil {
		m["wallet_address"] = strings.TrimSpace(string(b))
	}
	if b, err := os.ReadFile(filepath.Join(dir, "miner_address.txt")); err == nil {
		m["miner_address"] = strings.TrimSpace(string(b))
	}
	if b, err := os.ReadFile(filepath.Join(dir, "wallet_priv.hex")); err == nil {
		m["wallet_priv_hex"] = strings.TrimSpace(string(b))
	}
	if b, err := os.ReadFile(filepath.Join(dir, "wallet_balance.cache.json")); err == nil {
		var tmp interface{}
		_ = json.Unmarshal(b, &tmp)
		m["balance_cache"] = tmp
	}
	if b, err := os.ReadFile(filepath.Join(dir, "bonus_store.json")); err == nil {
		var tmp interface{}
		_ = json.Unmarshal(b, &tmp)
		m["bonus_store"] = tmp
	}
	return encryptJSONToFile(targetPath, m, pass)
}

func restoreWalletBackup(sourcePath, pass string) error {
	var m map[string]interface{}
	if err := decryptJSONFromFile(sourcePath, pass, &m); err != nil {
		return err
	}
	dir := nodeDir()
	if v, ok := m["wallet_address"].(string); ok {
		_ = os.WriteFile(filepath.Join(dir, "wallet_address.txt"), []byte(strings.TrimSpace(v)), 0644)
	}
	if v, ok := m["miner_address"].(string); ok {
		_ = os.WriteFile(filepath.Join(dir, "miner_address.txt"), []byte(strings.TrimSpace(v)), 0644)
	}
	if v, ok := m["wallet_priv_hex"].(string); ok {
		_ = os.WriteFile(filepath.Join(dir, "wallet_priv.hex"), []byte(strings.TrimSpace(v)), 0644)
	}
	if v, ok := m["balance_cache"]; ok {
		if b, err := json.MarshalIndent(v, "", "  "); err == nil {
			_ = os.WriteFile(filepath.Join(dir, "wallet_balance.cache.json"), b, 0644)
		}
	}
	if v, ok := m["bonus_store"]; ok {
		if b, err := json.MarshalIndent(v, "", "  "); err == nil {
			_ = os.WriteFile(filepath.Join(dir, "bonus_store.json"), b, 0644)
		}
	}
	return nil
}

/* ================== Miner start/stop & log tail ================== */

// panic / invalid base58 satırlarını kırmızı göstermek için
var rePanic = regexp.MustCompile(`(?i)\b(panic|invalid base58)\b`)
var (
	reBlock = regexp.MustCompile(`(?i)\b(block (found|mined)|new block)\b`)
	reHash  = regexp.MustCompile(`(?i)\b([a-f0-9]{16,})\b`)
)

// Yalnızca Base58 karakterlerini tutar
func cleanBase58(s string) string {
	s = strings.TrimSpace(s)
	var b strings.Builder
	for _, r := range s {
		if (r >= '1' && r <= '9') ||
			(r >= 'A' && r <= 'H') || (r >= 'J' && r <= 'N') || (r >= 'P' && r <= 'Z') ||
			(r >= 'a' && r <= 'k') || (r >= 'm' && r <= 'z') {
			b.WriteRune(r)
		}
	}
	return b.String()
}

func isLikelyBase58Address(s string) bool {
	if len(s) < 26 || len(s) > 50 {
		return false
	}
	for _, r := range s {
		if !((r >= '1' && r <= '9') ||
			(r >= 'A' && r <= 'H') || (r >= 'J' && r <= 'N') || (r >= 'P' && r <= 'Z') ||
			(r >= 'a' && r <= 'k') || (r >= 'm' && r <= 'z')) {
			return false
		}
	}
	return true
}

// Miner log dosyasını RichText’e canlı akıt
func startMinerTailInto(rich *widget.RichText) {
	minerTailMu.Lock()
	defer minerTailMu.Unlock()

	if minerTailStop != nil {
		close(minerTailStop)
		minerTailStop = nil
	}
	if minerLogPath == "" {
		return
	}
	f, err := os.Open(minerLogPath)
	if err != nil {
		return
	}
	// dosyanın sonundan tail et
	if _, err := f.Seek(0, io.SeekEnd); err != nil {
		_ = f.Close()
		return
	}
	stop := make(chan struct{})
	minerTailStop = stop

	go func() {
		defer f.Close()
		reader := bufio.NewReader(f)
		for {
			select {
			case <-stop:
				return
			default:
				line, err := reader.ReadString('\n')
				if err != nil {
					if err == io.EOF {
						time.Sleep(200 * time.Millisecond)
						continue
					}
					return
				}
				ui(func() { appendColoredLog(rich, line) })
				if reBlock.MatchString(line) && walletRefreshHook != nil {
					go walletRefreshHook()
				}
			}
		}
	}()
}

func stopMinerTail() {
	minerTailMu.Lock()
	defer minerTailMu.Unlock()
	if minerTailStop != nil {
		close(minerTailStop)
		minerTailStop = nil
	}
}

// Log satırı renklendirme
func appendColoredLog(rt *widget.RichText, line string) {
	// panic/invalid base58 => kırmızı
	if rePanic.MatchString(line) {
		rt.Segments = append(rt.Segments, &widget.TextSegment{
			Text: line,
			Style: widget.RichTextStyle{
				ColorName: theme.ColorNameError,
			},
		})
		rt.Refresh()
		return
	}

	// "block found/mined" kısımlarını yeşil yap
	segs := []widget.RichTextSegment{}
	idx := 0
	for _, loc := range reBlock.FindAllStringIndex(line, -1) {
		if loc[0] > idx {
			segs = append(segs, &widget.TextSegment{Text: line[idx:loc[0]]})
		}
		segs = append(segs, &widget.TextSegment{
			Text: line[loc[0]:loc[1]],
			Style: widget.RichTextStyle{
				ColorName: theme.ColorNameSuccess,
			},
		})
		idx = loc[1]
	}
	if idx < len(line) {
		segs = append(segs, &widget.TextSegment{Text: line[idx:]})
	}

	// içindeki hash’leri (hex) mavi renge boya
	colored := []widget.RichTextSegment{}
	for _, s := range segs {
		if txt, ok := s.(*widget.TextSegment); ok {
			chunks := splitByRegex(txt.Text, reHash)
			for _, c := range chunks {
				if reHash.MatchString(c) {
					colored = append(colored, &widget.TextSegment{
						Text: c,
						Style: widget.RichTextStyle{
							ColorName: theme.ColorNamePrimary,
						},
					})
				} else {
					colored = append(colored, &widget.TextSegment{Text: c})
				}
			}
		} else {
			colored = append(colored, s)
		}
	}

	rt.Segments = append(rt.Segments, colored...)
	rt.Refresh()
}

func splitByRegex(s string, r *regexp.Regexp) []string {
	out := []string{}
	last := 0
	for _, loc := range r.FindAllStringIndex(s, -1) {
		if last < loc[0] {
			out = append(out, s[last:loc[0]])
		}
		out = append(out, s[loc[0]:loc[1]])
		last = loc[1]
	}
	if last < len(s) {
		out = append(out, s[last:])
	}
	return out
}

/* ================== Miner starter ================== */

// API'yi arka planda doğrudan process olarak başlatır; logları api_out.log’a yazar.
func startAPIBackground() error {
	if apiPort == "" {
		apiPort = detectAPIPort()
	}
	if portHasAPI(apiPort) {
		return nil
	}

	dir := nodeDir()
	exe := filepath.Join(dir, "quantumcoin.exe")
	if _, err := os.Stat(exe); err != nil {
		return fmt.Errorf("quantumcoin.exe not found: %v", err)
	}

	// Log dosyası
	apiLog := filepath.Join(dir, "api_out.log")
	f, err := os.OpenFile(apiLog, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		return err
	}

	// Ortam — mevcut adres varsa tek-adres env’lerini sabitle
	env := os.Environ()
	if addr := strings.TrimSpace(detectExistingAddress()); addr != "" {
		env = append(env,
			"QC_COMMUNITY_ADDRESS="+addr,
			"QC_DEV_FUND_ADDRESS="+addr,
			"QC_PREMINE_ADDRESS="+addr,
		)
	}
	env = append(env, "QC_NODE_DIR="+dir)

	// Doğrudan başlat
	cmd := exec.Command(exe, "api")
	cmd.Dir = dir
	cmd.Env = env
	cmd.Stdout = f
	cmd.Stderr = f
	if err := cmd.Start(); err != nil {
		_ = f.Close()
		return err
	}
	// Arkada bekleyip dosyayı kapat
	go func() {
		_ = cmd.Wait()
		_ = f.Close()
	}()

	// Sağlık kontrolü
	health := apiBase() + "/health"
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		if ping(health, 500*time.Millisecond) == nil {
			return nil
		}
		time.Sleep(300 * time.Millisecond)
	}
	return fmt.Errorf("API timeout")
}

// Miner’ı başlat: API varsa /api/miner/start; yoksa CMD’de run-mine <addr>
func startMinerInCmd(addr string) error {
	addr = strings.TrimSpace(addr)
	if addr == "" {
		return fmt.Errorf("address empty")
	}

	// 1) API üzerinden miner'ı başlatmayı dene
	if portHasAPI(detectAPIPort()) {
		type req struct{ Address string `json:"address"` }
		if err := apiPost("/api/miner/start", req{Address: addr}, 2*time.Second); err == nil {
			minerRunningState = true
			if onMinerStateUpdate != nil {
				onMinerStateUpdate(true)
			}
			minerLogPath = filepath.Join(nodeDir(), "api_out.log")
			return nil
		}
	}

	// 2) Doğrudan process başlat (Windows: yeni CMD penceresi)
	dir := nodeDir()
	exe := filepath.Join(dir, "quantumcoin.exe")
	if _, err := os.Stat(exe); err != nil {
		return fmt.Errorf("quantumcoin.exe not found: %w", err)
	}
	minerLogPath = filepath.Join(dir, "miner_out.log")
	if f, err := os.OpenFile(minerLogPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644); err == nil {
		_ = f.Close()
	}

	if runtime.GOOS == "windows" {
		// PowerShell ile yeni pencere aç, logları dosyaya yönlendir, PID'i dosyaya yaz
		ps := fmt.Sprintf(
			`$dir='%s'; $exe=Join-Path $dir 'quantumcoin.exe'; `+
				`$log=Join-Path $dir 'miner_out.log'; $pidFile=Join-Path $dir 'miner_pid.txt'; `+
				`$args=@('%s'); `+
				`$p=Start-Process -FilePath $exe -ArgumentList $args -WorkingDirectory $dir -WindowStyle Normal -PassThru `+
				` -RedirectStandardOutput $log -RedirectStandardError $log; `+
				`Set-Content -Path $pidFile -Value $p.Id;`,
			strings.ReplaceAll(dir, `\`, `\\`),
			func() string {
				// argümanları minerSubcommand/minerNeedsAddrFlag ile üret
				if minerNeedsAddrFlag {
					return fmt.Sprintf(`%s','-addr','%s`, minerSubcommand, addr)
				}
				return fmt.Sprintf(`%s','%s`, minerSubcommand, addr)
			}(),
		)
		cmd := exec.Command("powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps)
		cmd.Dir = dir
		if err := cmd.Run(); err != nil { // kısa script, beklemek sorun değil
			return err
		}
		// PID'i oku ve kendi PID dosyamıza da yaz (lint "unused" uyarısı olmasın)
		if pid, err := readMinerPID(); err == nil && pid > 0 {
			writeMinerPID(pid)
		}

		minerRunningState = true
		if onMinerStateUpdate != nil {
			onMinerStateUpdate(true)
		}
		return nil
	}

	// 3) macOS/Linux: arka planda başlat, log dosyasına yaz
	cmd := exec.Command(exe, func() []string {
		if minerNeedsAddrFlag {
			return []string{minerSubcommand, "-addr", addr}
		}
		return []string{minerSubcommand, addr}
	}()...)
	cmd.Dir = dir
	lf, err := os.OpenFile(minerLogPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err == nil {
		cmd.Stdout = lf
		cmd.Stderr = lf
	}
	if err := cmd.Start(); err != nil {
		if lf != nil { _ = lf.Close() }
		return err
	}
	writeMinerPID(cmd.Process.Pid)
	go func() {
		_ = cmd.Wait()
		if lf != nil { _ = lf.Close() }
	}()

	minerRunningState = true
	if onMinerStateUpdate != nil {
		onMinerStateUpdate(true)
	}
	return nil
}


	// API yoksa tek pencere: node+api+mining bir arada
	dir := nodeDir()
	exe := filepath.Join(dir, "quantumcoin.exe")
	if _, err := os.Stat(exe); err != nil {
		return fmt.Errorf("quantumcoin.exe not found: %v", err)
	}

	// Batch dosyası (kolay başlatma için)
	runBat := filepath.Join(dir, "run_miner.cmd")
	content := fmt.Sprintf("@echo off\r\ncd /d \"%s\"\r\n\"%s\" run-mine \"%s\"\r\n", dir, exe, addr)
	_ = os.WriteFile(runBat, []byte(content), 0644)

	// Ortam
	env := os.Environ()
	env = append(env, "QC_NODE_DIR="+dir,
		"QC_COMMUNITY_ADDRESS="+addr,
		"QC_DEV_FUND_ADDRESS="+addr,
		"QC_PREMINE_ADDRESS="+addr,
	)

	// Ayrı pencere aç
	cmd := exec.Command("cmd", "/C", "start", "QuantumCoin Miner", runBat)
	cmd.Dir = dir
	cmd.Env = env
	if err := cmd.Start(); err != nil {
		return err
	}
	// PID almak zor; kullanıcı pencereyi kapatarak durdurabilir.
	minerRunningState = true
	if onMinerStateUpdate != nil {
		onMinerStateUpdate(true)
	}
	// Loglar ayrı pencerede akar; GUI'de tail edilecek dosya yok.
	return nil
}

func makeMinerTab(w fyne.Window, defaultAddr string) fyne.CanvasObject {
	addrEntry := widget.NewEntry()
	addrEntry.SetPlaceHolder(T("reward_addr"))
	if v := loadText(minerAddressPath()); v != "" {
		addrEntry.SetText(v)
	} else if defaultAddr != "" {
		addrEntry.SetText(defaultAddr)
	}

	statusLab := widget.NewLabel(T("stopped"))
	logView := widget.NewRichText()
	logView.Wrapping = fyne.TextWrapWord
	logView.Segments = []widget.RichTextSegment{&widget.TextSegment{Text: T("logs") + ":\n"}}

	// --- BAŞLAT ---
	startBtn := widget.NewButton(T("miner_start"), func() {
		// 1) Adresi toparla
		addr := strings.TrimSpace(addrEntry.Text)
		if addr == "" {
			if v := loadText(minerAddressPath()); v != "" {
				addr = v
			}
		}
		if addr == "" {
			if v := loadText(walletAddressPath()); v != "" {
				addr = v
			}
		}
		if addr == "" {
			if a, _, err := genAddressPrivViaNode(); err == nil && strings.TrimSpace(a) != "" {
				addr = a
			}
		}

		// 2) Base58 temizle + doğrula
		addr = cleanBase58(addr)
		addrEntry.SetText(addr)
		if addr == "" || !isLikelyBase58Address(addr) {
			dialog.ShowError(fmt.Errorf("Geçersiz ödül adresi (Base58)"), w)
			return
		}

		// 3) Kaydet
		if err := saveText(minerAddressPath(), addr); err != nil {
			dialog.ShowError(fmt.Errorf("Adres kaydedilemedi: %v", err), w)
			return
		}

		// 4) Zaten çalışıyorsa log’u bağla
		if minerActiveHeuristic() {
			dialog.ShowInformation(T("ok"), "Miner already running.", w)
			if minerLogPath == "" {
				minerLogPath = filepath.Join(nodeDir(), "api_out.log")
			}
			startMinerTailInto(logView)
			return
		}

		// 5) Başlat
		if err := startMinerInCmd(addr); err != nil {
			dialog.ShowError(fmt.Errorf("Miner could not start: %v", err), w)
			return
		}
		dialog.ShowInformation(T("ok"), "Miner started.", w)

		// 6) Log tail (API arka planda ise)
		if minerLogPath == "" {
			minerLogPath = filepath.Join(nodeDir(), "api_out.log")
		}
		if _, err := os.Stat(minerLogPath); err == nil {
			startMinerTailInto(logView)
		}

		// 7) Burst auto-refresh
		if walletRefreshHook != nil {
			go func() {
				deadline := time.Now().Add(30 * time.Second)
				for time.Now().Before(deadline) {
					time.Sleep(2 * time.Second)
					walletRefreshHook()
				}
			}()
		}
	})
	// --- DURDUR ---
	stopBtn := widget.NewButton(T("miner_stop"), func() {
		// 1) API üstünden durdurmayı dene (sessiz hata toleranslı)
		_ = apiPost("/api/miner/stop", map[string]string{}, 800*time.Millisecond)

		// 2) Bizim başlattığımız proses varsa öldür
		if pid, err := readMinerPID(); err == nil && pid > 0 {
			if runtime.GOOS == "windows" {
				_ = exec.Command("taskkill", "/PID", fmt.Sprint(pid), "/F").Run()
			} else {
				_ = exec.Command("kill", "-9", fmt.Sprint(pid)).Run()
			}
			clearMinerPID()
		}

		// 3) UI durumlarını güncelle
		minerRunningState = false
		if onMinerStateUpdate != nil {
			onMinerStateUpdate(false)
		}
		stopMinerTail()
		dialog.ShowInformation(T("ok"), "Miner stopped.", w)
	})

	// --- DİĞER ---
	refreshBtn := widget.NewButton(T("refresh"), func() {
		// Bakiye/height tazele
		if walletRefreshHook != nil {
			walletRefreshHook()
		}
		// Madenci durum etiketini anında güncelle
		if onMinerStateUpdate != nil {
			onMinerStateUpdate(minerActiveHeuristic())
		}
	})

	openLogBtn := widget.NewButton("Log Klasörünü Aç", func() {
		dir := nodeDir()
		if minerLogPath == "" {
			minerLogPath = filepath.Join(dir, "miner_out.log")
		}
		if runtime.GOOS == "windows" {
			_ = exec.Command("explorer.exe", dir).Start()
		} else {
			_ = exec.Command("xdg-open", dir).Start()
		}
	})

	openManualCmdBtn := widget.NewButton("CMD (manuel) aç", func() {
		// Var ise oluşturduğumuz batch’i aç; yoksa doğrudan satırla çalıştır.
		dir := nodeDir()
		runBat := filepath.Join(dir, "run_miner.cmd")
		if _, err := os.Stat(runBat); err == nil {
			_ = exec.Command("cmd", "/C", "start", "QuantumCoin Miner", runBat).Start()
			return
		}

		// Adresi toparla → boşsa miner_address.txt → wallet_address.txt → gerekirse üret
		addr := strings.TrimSpace(addrEntry.Text)
		if addr == "" {
			addr = loadText(minerAddressPath())
		}
		if addr == "" {
			addr = loadText(walletAddressPath())
		}
		if addr == "" {
			if v, err := genAddressViaNode(); err == nil && v != "" {
				addr = v
				_ = saveText(walletAddressPath(), addr)
				_ = saveText(minerAddressPath(), addr)
			}
		}
		addr = cleanBase58(addr)
		addrEntry.SetText(addr)
		if addr == "" || !isLikelyBase58Address(addr) {
			dialog.ShowError(fmt.Errorf("Geçersiz ödül adresi (Base58)"), w)
			return
		}
		_ = saveText(minerAddressPath(), addr)

		exe := filepath.Join(dir, "quantumcoin.exe")
		var line string
		if minerNeedsAddrFlag {
			// "%exe% mine -addr %addr%"
			line = fmt.Sprintf(`cd /d "%s" && "%s" %s -addr "%s"`, dir, exe, minerSubcommand, addr)
		} else {
			// "%exe% mine %addr%"
			line = fmt.Sprintf(`cd /d "%s" && "%s" %s "%s"`, dir, exe, minerSubcommand, addr)
		}
		_ = exec.Command("cmd", "/K", line).Start()
	})

	onMinerStateUpdate = func(running bool) {
		ui(func() {
			if running {
				statusLab.SetText(T("running"))
			} else {
				statusLab.SetText(T("stopped"))
			}
			statusLab.Refresh()
		})
	}
	// ilk açılışta heuristik durum
	onMinerStateUpdate(minerActiveHeuristic())

	top := widget.NewForm(
		widget.NewFormItem(T("reward_addr"), addrEntry),
		widget.NewFormItem(T("miner_status"), statusLab),
	)

	btnBar := container.NewHBox(
		startBtn,
		stopBtn,
		refreshBtn,
		openLogBtn,
		openManualCmdBtn,
	)

	// Butonlar üstte, log altta
	return container.NewVBox(
		top,
		btnBar,
		widget.NewSeparator(),
		container.NewVScroll(logView),
	)
}

/* ================== Web Wallet & API bootstrap ================== */

// Not: Üstte benzer bir fonksiyon zaten varsa çakışmaması için
// buradaki versiyonu farklı bir adla tanımlıyoruz.
func startAPIBackground2() error {
	if apiPort == "" {
		apiPort = detectAPIPort()
	}
	if portHasAPI(apiPort) {
		return nil
	}

	exe := filepath.Join(nodeDir(), "quantumcoin.exe")
	if _, err := os.Stat(exe); err != nil {
		return fmt.Errorf("quantumcoin.exe not found: %v", err)
	}

	var startErr error
	if runtime.GOOS == "windows" {
		// Arka planda CMD ile başlat (ekstra pencere istemiyorsak /B)
		cmd := exec.Command("cmd", "/C", "start", "", "/B", "/D", nodeDir(), "quantumcoin.exe", "api")
		cmd.Dir = nodeDir()
		startErr = cmd.Start()
	} else {
		cmd := exec.Command(exe, "api")
		cmd.Dir = nodeDir()
		startErr = cmd.Start()
	}
	if startErr != nil {
		return startErr
	}

	health := apiBase() + "/health"
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		if ping(health, 500*time.Millisecond) == nil {
			return nil
		}
		time.Sleep(300 * time.Millisecond)
	}
	return fmt.Errorf("API timeout")
}

func openWebWalletBrowser() error {
	u := "http://127.0.0.1:" + detectAPIPort()

	switch runtime.GOOS {
	case "windows":
		// PowerShell yerine CMD ile varsayılan tarayıcıyı aç
		return exec.Command("cmd", "/C", "start", "", u).Start()
	case "darwin":
		return exec.Command("open", u).Start()
	default:
		return exec.Command("xdg-open", u).Start()
	}
}

func makeWebWalletTab(w fyne.Window) fyne.CanvasObject {
	u := func() string { return "http://127.0.0.1:" + detectAPIPort() }
	urlLabel := widget.NewLabel(fmt.Sprintf(T("web_wallet_url"), u()))

	openBtn := widget.NewButton(T("open_web_wallet"), func() {
		if err := startAPIBackground2(); err != nil { // ← çakışma olmasın diye 2. sürümü çağırıyoruz
			dialog.ShowError(fmt.Errorf("%s %v", T("api_timeout"), err), w)
			return
		}
		urlLabel.SetText(fmt.Sprintf(T("web_wallet_url"), u()))
		if err := openWebWalletBrowser(); err != nil {
			dialog.ShowError(fmt.Errorf("Web wallet could not open: %v", err), w)
			return
		}
		dialog.ShowInformation(T("ok"), "Web wallet opened in browser.", w)
	})

	return container.NewVBox(urlLabel, openBtn)
}

/* ================== Build UI & main ================== */

func makeLangSelect(w fyne.Window) *widget.Select {
	if langSelect != nil {
		return langSelect
	}
	langSelect = widget.NewSelect([]string{
		"Türkçe (tr)", "English (en)", "Español (es)", "中文 (zh)",
	}, func(s string) {
		switch {
		case strings.Contains(s, "(tr)"):
			curLang = "tr"
		case strings.Contains(s, "(en)"):
			curLang = "en"
		case strings.Contains(s, "(es)"):
			curLang = "es"
		case strings.Contains(s, "(zh)"):
			curLang = "zh"
		}
		// Otomatik yenilemeyi sıfırla ve UI'ı yeniden kur
		if walletAutoRefreshStop != nil {
			close(walletAutoRefreshStop)
			walletAutoRefreshStop = nil
		}
		w.SetTitle(T("title") + " — " + appVersion)
		buildUI(w)
	})
	langSelect.SetSelected("Türkçe (tr)")
	return langSelect
}

func buildUI(w fyne.Window) {
	myAddrEntry := widget.NewEntry()
	fromEntry := widget.NewEntry()
	myAddrEntry.SetPlaceHolder(T("my_address"))
	fromEntry.SetPlaceHolder(T("from"))

	// ---- Tek-adres politikası & env sabitleme (async) ----
	go func() {
		addr := detectExistingAddress()
		if strings.TrimSpace(addr) == "" {
			if a, err := genAddressViaNode(); err == nil && strings.TrimSpace(a) != "" {
				_ = saveText(walletAddressPath(), a)
				_ = saveText(minerAddressPath(), a)
				addr = a
			}
		}
		addr = cleanBase58(addr)
		if addr != "" {
			_ = os.Setenv("QC_COMMUNITY_ADDRESS", addr)
			_ = os.Setenv("QC_DEV_FUND_ADDRESS", addr)
			_ = os.Setenv("QC_PREMINE_ADDRESS", addr)
			_ = os.Setenv("QC_NODE_DIR", nodeDir())
			ensureBonusStore(addr)
		}
	}()

	// Var olan adresleri otomatik doldur
	if addr := detectExistingAddress(); addr != "" {
		myAddrEntry.SetText(addr)
		fromEntry.SetText(addr)
	}

	// Adres boşsa node üzerinden üret ve dosyaya yaz
	if strings.TrimSpace(myAddrEntry.Text) == "" {
		if addr, err := genAddressViaNode(); err == nil && strings.TrimSpace(addr) != "" {
			_ = saveText(walletAddressPath(), addr)
			_ = saveText(minerAddressPath(), addr)
			myAddrEntry.SetText(addr)
			fromEntry.SetText(addr)
		}
	}

	themeSel := widget.NewSelect([]string{"Otomatik", "Aydınlık", "Karanlık"}, func(s string) { applyTheme(s) })
	themeSel.SetSelected("Otomatik")

	tabs := container.NewAppTabs(
		container.NewTabItem(T("tab_wallet"), makeWalletTab(w, myAddrEntry, fromEntry)),
		container.NewTabItem(T("tab_mine"), makeMinerTab(w, myAddrEntry.Text)),
		container.NewTabItem(T("tab_web"), makeWebWalletTab(w)),
	)

	header := container.NewBorder(
		nil, nil,
		widget.NewLabelWithStyle(T("title"), fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		container.NewHBox(themeSel, makeLangSelect(w)),
	)

	w.SetContent(container.NewBorder(header, nil, nil, nil, tabs))
}

func main() {
	runtime.LockOSThread()
	a := app.NewWithID("quantumcoin.gui")
	w := a.NewWindow(T("title") + " — " + appVersion)
	w.Resize(fyne.NewSize(1000, 700))
	makeLangSelect(w) // default TR selected
	buildUI(w)
	w.Show()
	a.Run()
}
